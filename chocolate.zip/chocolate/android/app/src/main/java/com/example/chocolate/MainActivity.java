package com.example.Gifts;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
