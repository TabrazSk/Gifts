import 'package:flutter/material.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Your cart is empty!',
          style: TextStyle(
            fontSize: 25,
          ),
        ),
      ),
      backgroundColor:Colors.cyan[100],
    );
  }
}
