import 'package:flutter/material.dart';

class CustomBottomNavbar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;


  const CustomBottomNavbar({
    required this.currentIndex,
    required this.onTap

  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      backgroundColor: Colors.white70,
      currentIndex: currentIndex,
      onTap: onTap,
      selectedItemColor: Colors.pink[200],
      unselectedItemColor: Colors.black,
      showUnselectedLabels: true,

      items: [
        BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
              color: currentIndex == 0 ? Colors.blueAccent : Colors.redAccent,

            ),label: 'Home'
        ),

        //BottomNavigationBarItem(icon: Icon(Icons.card_giftcard_outlined,
        //  color: currentIndex == 1 ? Colors.black : Colors.purpleAccent,
        //),
        //    label: 'Gifts'
        //),

        BottomNavigationBarItem(icon: Icon(Icons.shopping_cart,
          color: currentIndex == 2 ? Colors.black : Colors.greenAccent,
        ),
            label: 'Cart'
        ),

        BottomNavigationBarItem(icon: Icon(Icons.support_agent,
          color: currentIndex == 3 ? Colors.blueAccent : Colors.orangeAccent,
        ),
            label: 'Support'
        ),
      ],
    );
  }
}